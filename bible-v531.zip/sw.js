/* Bible · offline service worker */
var CACHE = 'bible-v531';
/* Lightweight shell only. Chapters cache themselves as they're read (runtime
   caching in the fetch handler). Full-Bible offline is opt-in via "Save for
   offline" -> postMessage('saveOffline'). Keeps first visit feather-light. */
var SHELL = [
  '/', '/index.html', '/books.json', '/manifest.json', '/redletter.json',
  '/icon-192.png', '/icon-512.png', '/apple-touch-icon.png', '/og.png', '/favicon-32.png'
];

self.addEventListener('install', function (e) {
  self.skipWaiting();
  e.waitUntil(
    caches.open(CACHE).then(function (c) {
      return Promise.all(SHELL.map(function (u) { return c.add(u).catch(function () {}); }));
    }).then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.map(function (k) { if (k !== CACHE) return caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  if (url.origin !== location.origin) return; // fonts etc. straight to network

  // Network-first for the app shell (HTML): online always gets the freshest
  // page on a normal refresh; offline falls back to the cached shell.
  // Only the ROOT navigation is cached as /index.html — static SEO pages
  // (e.g. /john/3/) are network-first but must NOT overwrite the app shell.
  var isRoot = (url.pathname === '/' || url.pathname === '/index.html');
  if (req.mode === 'navigate' || isRoot) {
    e.respondWith(
      fetch(req, { cache: 'no-store' }).then(function (res) {
        if (isRoot) {
          var copy = res.clone();
          caches.open(CACHE).then(function (c) { c.put('/index.html', copy); });
        }
        return res;
      }).catch(function () {
        return caches.match(req).then(function (h) { return h || caches.match('/index.html'); });
      })
    );
    return;
  }

  // Cache-first for everything else (chapters, data, icons): instant + offline.
  e.respondWith(
    caches.match(req).then(function (hit) {
      return hit || fetch(req).then(function (res) {
        // NEVER cache error responses (404/5xx) — a cached 404 would be served
        // forever even after the file is deployed. Only cache real successes.
        // Also never cache an HTML response to a non-HTML request: that's the
        // SPA fallback (index.html) served for a MISSING asset (e.g. a data
        // .json file). Caching it would silently poison data loads until the
        // next version bump. Let it pass through uncached so a later deploy of
        // the real file immediately works.
        if (res && res.ok) {
          var ct = res.headers.get('content-type') || '';
          if (ct.indexOf('text/html') === -1) {
            var copy = res.clone();
            caches.open(CACHE).then(function (c) { c.put(req, copy); });
          }
        }
        return res;
      }).catch(function () {
        if (req.mode === 'navigate') return caches.match('/index.html');
        return new Response('', { status: 504 });
      });
    })
  );
});

/* Opt-in: download the full KJV for offline use, reporting progress.
   One file at a time (gentle on weak connections); skips already-cached. */
self.addEventListener('message', function (e) {
  var msg = e.data || {};
  if (msg.type !== 'saveOffline') return;
  var urls = ['/redletter.json','/fn-photo.webp','/fn-sig.webp',
    '/fonts/literata-latin-300-normal.woff2','/fonts/literata-latin-400-normal.woff2',
    '/fonts/literata-latin-500-normal.woff2','/fonts/literata-latin-600-normal.woff2',
    '/fonts/inter-latin-400-normal.woff2','/fonts/inter-latin-500-normal.woff2','/fonts/inter-latin-600-normal.woff2','/fonts/inter-latin-700-normal.woff2',
    '/fonts/spectral-latin-300-normal.woff2','/fonts/spectral-latin-400-normal.woff2','/fonts/spectral-latin-500-normal.woff2'];
  for (var i = 1; i <= 66; i++) urls.push('/books/' + i + '.json');
  var total = urls.length, done = 0;
  function report(t) { if (e.source) e.source.postMessage(t); }
  caches.open(CACHE).then(function (c) {
    function next(idx) {
      if (idx >= urls.length) { report({ type: 'offlineDone' }); return; }
      c.match(urls[idx]).then(function (hit) {
        (hit ? Promise.resolve() : c.add(urls[idx]).catch(function () {})).then(function () {
          done++; report({ type: 'offlineProgress', done: done, total: total });
          next(idx + 1);
        });
      });
    }
    next(0);
  });
});
